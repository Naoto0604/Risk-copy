"""M7: NVD CVE 候補照合。

バナー文字列は未検証の観測値として扱う。NVD の CPE 一致は候補であり、
対象ホストがそのビルドで動いている証明ではない。

通信は ``collectors.http.client.fetch`` 経由。NVD は診断対象の外なので、
スコープ判定を通さない専用 Scheduler を立て、6 秒間隔はレート制限に任せる。
"""

from __future__ import annotations

import json
import os
import re
import threading
import time
from urllib.parse import urlencode

import requests

from collectors.http import client
from engine.rule_runner import Finding, finding_id
from engine.scheduler import Budgets, Scheduler

NVD_CVE_API = "https://services.nvd.nist.gov/rest/json/cves/2.0"
REQUEST_TIMEOUT = (3.05, 6.0)
RESULTS_PER_PAGE = 20
MAX_CVES_PER_PRODUCT = 5
MAX_PRODUCTS_PER_SCAN = 3
CACHE_TTL_SECONDS = 30 * 60
ERROR_CACHE_TTL_SECONDS = 60
#: NVD は未認証の連続呼び出しを推奨しない。Scheduler のレート制限に載せる。
MIN_REQUEST_INTERVAL_SECONDS = 6.0

PRODUCT_PATTERNS = (
    {
        "name": "MySQL Server",
        "vendor": "oracle",
        "product": "mysql",
        "component_scope": "server",
        "regex": re.compile(
            r"Observed MySQL server version string \(unverified\):\s*"
            r"(\d+\.\d+\.\d+)(?:[-+][A-Za-z0-9._-]+)?",
            re.IGNORECASE,
        ),
    },
    {
        "name": "OpenSSH",
        "vendor": "openbsd",
        "product": "openssh",
        "component_scope": "server",
        "regex": re.compile(
            r"Observed SSH banner \(unverified\):\s*SSH-\d+\.\d+-OpenSSH[_-]"
            r"(\d+(?:\.\d+){1,2}(?:p\d+)?)",
            re.IGNORECASE,
        ),
    },
    {
        "name": "Apache HTTP Server",
        "vendor": "apache",
        "product": "http_server",
        "component_scope": "server",
        "regex": re.compile(
            r"Server header \(unverified banner\):\s*Apache/(\d+\.\d+\.\d+)",
            re.IGNORECASE,
        ),
    },
)

_CACHE: dict[str, tuple[float, dict]] = {}
_CACHE_LOCK = threading.Lock()


def _scheduler(timeout: float) -> Scheduler:
    """NVD 照合用。スコープ判定は通さず、間隔だけ守る。"""
    budgets = Budgets(
        requests=MAX_PRODUCTS_PER_SCAN + 2,
        per_host_interval=MIN_REQUEST_INTERVAL_SECONDS,
    )
    instance = Scheduler(budgets, scope=lambda url: True)
    instance.http_timeout = lambda: (timeout, timeout)
    instance.start()
    return instance


def _nvd_transport(api_key: str):
    """``apiKey`` を載せる transport。予算・中断・再試行は fetch 側のまま効く。"""
    def send(url: str, method: str, timeout: tuple[float, float]):
        headers = {"User-Agent": "RiskTrace/0.7 vulnerability-candidate-lookup"}
        if api_key:
            headers["apiKey"] = api_key
        response = requests.request(method, url, headers=headers,
                                    timeout=timeout, allow_redirects=False)
        return response.status_code, tuple(response.headers.items()), response.content

    return send


def _build_nvd_url(cpe: str) -> str:
    """NVD CVE API の URL を組み立てる。真偽フラグは値を持たない。"""
    query = urlencode({"cpeName": cpe, "resultsPerPage": RESULTS_PER_PAGE})
    return f"{NVD_CVE_API}?{query}&isVulnerable&noRejected"


def _fetch_nvd_by_cpe(cpe: str, scheduler: Scheduler | None = None) -> dict:
    """CPE 完全一致で 1 回だけ引く。結果はキャッシュする。"""
    now = time.monotonic()

    with _CACHE_LOCK:
        cached = _CACHE.get(cpe)
        if cached and cached[0] > now:
            result = cached[1]
            if result.get("error"):
                raise RuntimeError(result["error"])
            return result

    url = _build_nvd_url(cpe)
    instance = scheduler or _scheduler(REQUEST_TIMEOUT[1])
    api_key = os.getenv("NVD_API_KEY", "").strip()

    try:
        response = client.fetch(url, instance, transport=_nvd_transport(api_key))
        if response.status != 200:
            raise ValueError(f"NVD API returned HTTP {response.status}")
        payload = json.loads(response.text)
        if not isinstance(payload, dict):
            raise ValueError("NVD API returned a non-object JSON response")
        result = {
            "vulnerabilities": payload.get("vulnerabilities", []),
            "total_results": int(payload.get("totalResults", 0) or 0),
            "source_url": url,
            "error": None,
        }
        with _CACHE_LOCK:
            _CACHE[cpe] = (time.monotonic() + CACHE_TTL_SECONDS, result)
        return result
    except (client.FetchError, requests.RequestException, ValueError, TypeError) as exc:
        error_result = {"error": _safe_error_text(str(exc)), "source_url": url}
        with _CACHE_LOCK:
            _CACHE[cpe] = (time.monotonic() + ERROR_CACHE_TTL_SECONDS, error_result)
        raise RuntimeError(error_result["error"]) from exc


def _safe_error_text(value: str, limit: int = 500) -> str:
    text = str(value or "NVD query failed")
    text = "".join(ch for ch in text if ch in "\t" or ord(ch) >= 32)
    return text[:limit]


def _english_description(cve: dict) -> str:
    descriptions = cve.get("descriptions", [])
    for item in descriptions:
        if item.get("lang") == "en" and item.get("value"):
            return str(item["value"])[:1200]
    for item in descriptions:
        if item.get("value"):
            return str(item["value"])[:1200]
    return "NVD に説明文が登録されていません。"


def _cvss_summary(cve: dict) -> tuple[str | None, str | None, str | None]:
    metrics = cve.get("metrics") or {}
    for metric_key in ("cvssMetricV40", "cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
        entries = metrics.get(metric_key) or []
        if not entries:
            continue
        entry = entries[0]
        data = entry.get("cvssData") or {}
        score = data.get("baseScore")
        severity = data.get("baseSeverity") or entry.get("baseSeverity")
        vector = data.get("vectorString")
        return (
            str(score) if score is not None else None,
            str(severity).upper() if severity else None,
            str(vector) if vector else None,
        )
    return None, None, None


def _cve_text(cve: dict) -> str:
    """コンポーネント判定にだけ使うテキスト。"""
    parts = []
    title = cve.get("sourceIdentifier")
    if title:
        parts.append(str(title))
    for item in cve.get("descriptions") or []:
        if isinstance(item, dict) and item.get("value"):
            parts.append(str(item["value"]))
    return "\n".join(parts)


def _component_mismatch_reason(product: dict, cve: dict) -> str | None:
    """サーバー役割と合わないクライアント側 CVE を落とす。"""
    if product.get("vendor") != "oracle" or product.get("product") != "mysql":
        return None
    if product.get("component_scope") != "server":
        return None

    text = _cve_text(cve)
    client_product = re.search(
        r"\bmysql\s+client\s+product\s+of\s+(?:oracle\s+)?mysql\b",
        text,
        re.IGNORECASE,
    )
    client_c_api = re.search(r"\bcomponent\s*:\s*c\s+api\b", text, re.IGNORECASE)
    if client_product or (client_c_api and re.search(r"\bmysql\s+client\b", text, re.IGNORECASE)):
        cve_id = cve.get("id", "unknown CVE")
        return (
            f"{cve_id} was excluded because its description identifies the MySQL Client/C API, "
            "while the observed banner was classified as MySQL Server."
        )
    return None


def _version_tokens(version: str) -> tuple[tuple[int, object], ...]:
    tokens = re.findall(r"\d+|[A-Za-z]+", str(version or "").lower())
    result = []
    for token in tokens:
        if token.isdigit():
            result.append((0, int(token)))
        else:
            result.append((1, token))
    return tuple(result)


def _compare_versions(left: str, right: str) -> int:
    left_tokens = list(_version_tokens(left))
    right_tokens = list(_version_tokens(right))
    if not left_tokens or not right_tokens:
        raise ValueError("version cannot be compared")
    max_len = max(len(left_tokens), len(right_tokens))
    left_tokens.extend([(0, 0)] * (max_len - len(left_tokens)))
    right_tokens.extend([(0, 0)] * (max_len - len(right_tokens)))
    left_tuple = tuple(left_tokens)
    right_tuple = tuple(right_tokens)
    return (left_tuple > right_tuple) - (left_tuple < right_tuple)


def _cpe_fields(criteria: str) -> tuple[str, str, str, str] | None:
    if not isinstance(criteria, str) or not criteria.startswith("cpe:2.3:"):
        return None
    parts = criteria.split(":")
    if len(parts) < 6:
        return None
    part, vendor, product, version = parts[2:6]
    if any("\\" in value for value in (vendor, product, version)):
        return None
    return part.lower(), vendor.lower(), product.lower(), version


def _iter_cpe_matches(value):
    if isinstance(value, dict):
        matches = value.get("cpeMatch")
        if isinstance(matches, list):
            for item in matches:
                if isinstance(item, dict):
                    yield item
        for key, child in value.items():
            if key != "cpeMatch":
                yield from _iter_cpe_matches(child)
    elif isinstance(value, list):
        for item in value:
            yield from _iter_cpe_matches(item)


def _range_description(match: dict) -> str:
    fields = (
        ("versionStartIncluding", "versionStartIncluding"),
        ("versionStartExcluding", "versionStartExcluding"),
        ("versionEndIncluding", "versionEndIncluding"),
        ("versionEndExcluding", "versionEndExcluding"),
    )
    bits = [f"{label}={match[key]}" for key, label in fields if match.get(key)]
    if bits:
        return ", ".join(bits)
    criteria = match.get("criteria") or match.get("cpe23Uri") or ""
    parsed = _cpe_fields(criteria)
    if parsed and parsed[3] not in {"*", "-"}:
        return f"exact CPE version {parsed[3]}"
    return "version wildcard in CPE criteria (no explicit range)"


def _match_version_range(observed_version: str, match: dict) -> tuple[bool, str]:
    criteria = match.get("criteria") or match.get("cpe23Uri") or ""
    parsed = _cpe_fields(criteria)
    criteria_version = parsed[3] if parsed else "*"

    try:
        if criteria_version not in {"*", "-"}:
            if _compare_versions(observed_version, criteria_version) != 0:
                return False, f"observed version {observed_version} differs from criteria version {criteria_version}"
        for key, op in (
            ("versionStartIncluding", ">="),
            ("versionStartExcluding", ">"),
            ("versionEndIncluding", "<="),
            ("versionEndExcluding", "<"),
        ):
            bound = match.get(key)
            if not bound:
                continue
            comparison = _compare_versions(observed_version, str(bound))
            valid = {
                ">=": comparison >= 0,
                ">": comparison > 0,
                "<=": comparison <= 0,
                "<": comparison < 0,
            }[op]
            if not valid:
                return False, f"observed version {observed_version} is outside {key}={bound}"
    except (TypeError, ValueError):
        return False, "version range could not be compared safely"

    return True, _range_description(match)


def _assess_cpe_applicability(product: dict, cve: dict) -> tuple[str, str]:
    """(状態, 注記) を返す。状態は MATCH / UNKNOWN / PRODUCT_MISMATCH / VERSION_MISMATCH。"""
    configurations = cve.get("configurations")
    if not isinstance(configurations, list) or not configurations:
        return (
            "UNKNOWN",
            "NVD response contained no usable configuration entries; affected-version applicability was not independently verified.",
        )

    cpe_matches = list(_iter_cpe_matches(configurations))
    matching_identity = []
    target_vendor = str(product.get("vendor", "")).lower()
    target_product = str(product.get("product", "")).lower()

    for match in cpe_matches:
        if match.get("vulnerable") is False:
            continue
        criteria = match.get("criteria") or match.get("cpe23Uri") or ""
        parsed = _cpe_fields(criteria)
        if not parsed:
            continue
        part, vendor, cpe_product, _version = parsed
        if part != "a" or vendor != target_vendor or cpe_product != target_product:
            continue
        matching_identity.append(match)

    if not matching_identity:
        return (
            "PRODUCT_MISMATCH",
            f"No vulnerable application CPE entry matched target identity {target_vendor}:{target_product}.",
        )

    for match in matching_identity:
        in_range, range_note = _match_version_range(product["version"], match)
        if in_range:
            return (
                "MATCH",
                f"NVD CPE product identity matched; observed version {product['version']} matched {range_note}. Other configuration, build and installation conditions remain unverified.",
            )

    reasons = [_match_version_range(product["version"], item)[1] for item in matching_identity]
    return (
        "VERSION_MISMATCH",
        f"No matching CPE version range included observed version {product['version']}. Details: {'; '.join(reasons[:3])}",
    )


def _candidate_finding(product: dict, cve: dict, source_url: str,
                       applicability_status: str = "UNKNOWN",
                       applicability_note: str | None = None) -> dict:
    cve_id = str(cve.get("id", "UNKNOWN-CVE"))
    description = _english_description(cve)
    score, cvss_severity, vector = _cvss_summary(cve)
    published = cve.get("published") or "unknown"
    evidence_lines = [
        f"Product (banner-derived, unverified): {product['name']}",
        f"Observed version (unverified): {product['version']}",
        f"CPE queried: {product['cpe']}",
        f"NVD CVE: {cve_id}",
        f"NVD published: {published}",
        f"NVD record URL: https://nvd.nist.gov/vuln/detail/{cve_id}",
        f"NVD query URL: {source_url}",
        f"CPE applicability status: {applicability_status}",
        "Installed package/build and full environment conditions are not verified.",
    ]
    if applicability_note:
        evidence_lines.append(f"CPE applicability assessment: {applicability_note}")
    if score is not None:
        evidence_lines.append(f"NVD CVSS base score: {score}")
    if cvss_severity:
        evidence_lines.append(f"NVD CVSS severity: {cvss_severity}")
    if vector:
        evidence_lines.append(f"NVD CVSS vector: {vector}")
    if product.get("banner_evidence"):
        evidence_lines.append(f"Observed banner (unverified): {product['banner_evidence']}")

    if applicability_status == "MATCH":
        applicability_summary = (
            "NVDのCPE構成に含まれる製品識別子とバージョン条件が観測値に一致しました。"
            "ただしビルド・依存条件・構成条件・実際にインストールされたビルドは未確認です。"
        )
    else:
        applicability_summary = (
            "CVEは参照候補として取得されましたが、NVDのCPE構成データから対象バージョンへの"
            "適用可否を判定して確認できていません。"
        )
    description_text = (
        f"{product['name']} {product['version']} の未検証バナーから {cve_id} が候補として返されました。"
        f"{applicability_summary} バナー文字列だけで脆弱性が存在すると断定しないでください。\n\n"
        f"NVD description: {description}"
    )
    if applicability_note:
        description_text += f"\n\nCPE照合メモ: {applicability_note}"
    if score is not None:
        description_text += f"\nNVDの登録CVSS基本スコア: {score}"
        if cvss_severity:
            description_text += f" ({cvss_severity})"

    return {
        "type": "VULNERABILITY_LOOKUP",
        "subtype": "CVE_VERSION_CANDIDATE",
        "severity": "INFO",
        "title": f"CVE候補 {cve_id}: {product['name']} {product['version']}（未検証）",
        "url": product.get("url") or "http://localhost/",
        "description": description_text[:2500],
        "evidence": "\n".join(evidence_lines)[:9000],
        "recommendation": (
            "対象ホストの管理者が、正確な製品・パッケージ管理情報で製品と正確なビルド番号を確認し、"
            "NVDのCVE詳細ページにある影響バージョン・前提条件と照合してください。"
            "該当が確認できた場合は、ベンダーが提示する修正版への更新や緩和策を評価してください。"
        ),
    }


def _status_finding(product: dict, subtype: str, message: str,
                    source_url: str | None = None) -> dict:
    if subtype == "NO_CVE_MATCH_FOUND":
        title = f"NVD照合: {product['name']} {product['version']} に一致するCVE候補なし"
        recommendation = (
            "候補が見つからなくても脆弱性が存在しないことの証明にはなりません。"
            "製品の正確なビルド・パッケージ情報とベンダーのセキュリティ情報も確認してください。"
        )
        description = (
            f"NVDの指定CPE検索では {product['name']} {product['version']} に一致する候補が返されませんでした。"
            "バナー由来のバージョンは未検証であり、NVD側の情報不足・製品名の違い・ベンダー固定パッチなどにより"
            "検索結果に表れない場合があります。脆弱性が存在しないと断定する結果ではありません。"
        )
    elif subtype in {
        "CANDIDATES_EXCLUDED_BY_COMPONENT",
        "CANDIDATES_OUTSIDE_AFFECTED_VERSION_RANGE",
        "CANDIDATES_FILTERED_BY_CPE_APPLICABILITY",
    }:
        title = f"NVD候補を適用条件で確認: {product['name']} {product['version']}"
        recommendation = (
            "NVDのCPE構成と製品コンポーネントを手動で確認し、対象ホストの正確な製品・ビルド・構成と照合してください。"
            "この結果は候補をフィルターした結果であり、脆弱性が存在しないことの証明ではありません。"
        )
        if subtype == "CANDIDATES_EXCLUDED_BY_COMPONENT":
            description = "NVDから返されたCVE候補は、観測したサービスのコンポーネントと一致しないと判断されたため除外しました。"
        elif subtype == "CANDIDATES_OUTSIDE_AFFECTED_VERSION_RANGE":
            description = "NVDから返されたCVE候補のうち、観測バージョンがCPEの示す影響バージョン範囲に一致するものはありませんでした。"
        else:
            description = "NVDから返されたCVE候補は、製品識別子またはバージョン条件を観測値と照合できなかったため候補から除外しました。"
        description += " バナー由来の製品・バージョンは未検証なので、最終判断には管理者とベンダー情報の確認が必要です。"
    else:
        title = f"NVD照合を完了できませんでした: {product['name']} {product['version']}"
        recommendation = (
            "ネットワーク接続とNVDの制限、APIレート制限を確認してから再試行してください。"
            "照合が完了するまでは脆弱性の有無を判断しないでください。"
        )
        description = (
            f"{product['name']} {product['version']} のNVD照合を完了できませんでした。"
            "これは脆弱性がないことを意味しません。"
        )

    evidence = [
        f"Product (banner-derived, unverified): {product['name']}",
        f"Observed version (unverified): {product['version']}",
        f"CPE queried: {product['cpe']}",
        f"Lookup status: {subtype}",
        f"Details: {_safe_error_text(message)}",
    ]
    if source_url:
        evidence.append(f"NVD query URL: {source_url}")
    if product.get("banner_evidence"):
        evidence.append(f"Observed banner (unverified): {product['banner_evidence']}")

    return {
        "type": "VULNERABILITY_LOOKUP",
        "subtype": subtype,
        "severity": "INFO",
        "title": title,
        "url": product.get("url") or "http://localhost/",
        "description": description,
        "evidence": "\n".join(evidence)[:9000],
        "recommendation": recommendation,
    }


def _safe_float(value) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return -1.0


def extract_observed_products(findings: list[dict]) -> list[dict]:
    """PORT_SCAN の evidence から、狭く認定できた製品とバージョンだけを拾う。"""
    products: dict[str, dict] = {}

    for finding in findings or []:
        if not isinstance(finding, dict) or finding.get("type") != "PORT_SCAN":
            continue
        evidence = finding.get("evidence")
        if not isinstance(evidence, str) or not evidence:
            continue

        for definition in PRODUCT_PATTERNS:
            match = definition["regex"].search(evidence)
            if not match:
                continue

            version = match.group(1)
            cpe = (
                f"cpe:2.3:a:{definition['vendor']}:{definition['product']}"
                f":{version}:*:*:*:*:*:*:*"
            )
            if cpe not in products:
                products[cpe] = {
                    "name": definition["name"],
                    "vendor": definition["vendor"],
                    "product": definition["product"],
                    "component_scope": definition.get("component_scope", "unknown"),
                    "version": version,
                    "cpe": cpe,
                    "url": finding.get("url", ""),
                    "banner_evidence": match.group(0)[:500],
                }
            break

    return list(products.values())[:MAX_PRODUCTS_PER_SCAN]


def lookup_cve_candidates(findings: list[dict]) -> list[dict]:
    """認定できたバナー由来 CPE について、CVE 候補と状態の Finding を返す。"""
    products = extract_observed_products(findings)
    result_findings: list[dict] = []

    for product in products:
        try:
            response_data = _fetch_nvd_by_cpe(product["cpe"])
        except (RuntimeError, requests.RequestException) as exc:
            result_findings.append(
                _status_finding(product, "NVD_LOOKUP_UNAVAILABLE", str(exc))
            )
            continue

        source_url = response_data.get("source_url") or _build_nvd_url(product["cpe"])
        vulnerabilities = response_data.get("vulnerabilities") or []
        accepted: list[tuple[dict, str, str]] = []
        filtered_component: list[str] = []
        filtered_version: list[str] = []
        filtered_product: list[str] = []

        for wrapper in vulnerabilities:
            if not isinstance(wrapper, dict):
                continue
            cve = wrapper.get("cve") or {}
            if not isinstance(cve, dict):
                continue
            status = str(cve.get("vulnStatus", "")).lower()
            if status in {"rejected", "reject"}:
                continue
            cve_id = cve.get("id")
            if not isinstance(cve_id, str) or not re.fullmatch(r"CVE-\d{4}-\d{4,}", cve_id):
                continue

            component_reason = _component_mismatch_reason(product, cve)
            if component_reason:
                filtered_component.append(component_reason)
                continue

            applicability_status, applicability_note = _assess_cpe_applicability(product, cve)
            if applicability_status == "PRODUCT_MISMATCH":
                filtered_product.append(f"{cve_id}: {applicability_note}")
                continue
            if applicability_status == "VERSION_MISMATCH":
                filtered_version.append(f"{cve_id}: {applicability_note}")
                continue
            accepted.append((cve, applicability_status, applicability_note))

        accepted.sort(
            key=lambda item: (
                _cvss_summary(item[0])[0] is not None,
                _safe_float(_cvss_summary(item[0])[0]),
            ),
            reverse=True,
        )
        if not accepted:
            if filtered_component and not filtered_version and not filtered_product:
                subtype = "CANDIDATES_EXCLUDED_BY_COMPONENT"
                details = "; ".join(filtered_component[:5])
            elif filtered_version and not filtered_component and not filtered_product:
                subtype = "CANDIDATES_OUTSIDE_AFFECTED_VERSION_RANGE"
                details = "; ".join(filtered_version[:5])
            elif filtered_component or filtered_version or filtered_product:
                subtype = "CANDIDATES_FILTERED_BY_CPE_APPLICABILITY"
                details = "; ".join((filtered_component + filtered_version + filtered_product)[:5])
            else:
                subtype = "NO_CVE_MATCH_FOUND"
                details = "NVD CPE search returned no non-rejected CVE candidates."
            result_findings.append(_status_finding(product, subtype, details, source_url))
            continue

        for cve, applicability_status, applicability_note in accepted[:MAX_CVES_PER_PRODUCT]:
            result_findings.append(
                _candidate_finding(
                    product,
                    cve,
                    source_url,
                    applicability_status=applicability_status,
                    applicability_note=applicability_note,
                )
            )

    return result_findings


def _banner_line(port: int, banner: str) -> str | None:
    """ポート観測のバナーを、既存の正規表現が読める形に包む。"""
    if port == 3306:
        return f"Observed MySQL server version string (unverified): {banner}"
    if port == 22:
        return f"Observed SSH banner (unverified): {banner}"
    return None


def _pseudo_findings(observations) -> tuple[list[dict], str]:
    """v2 の観測から、v1 形式の evidence 行を組み立てる。"""
    pseudo: list[dict] = []
    subject = ""

    for observation in observations:
        if getattr(observation, "collector", None) != "ports":
            continue
        subject = subject or str(getattr(observation, "subject", "") or "")
        data = getattr(observation, "data", None) or {}
        for entry in data.get("ports", []):
            if entry.get("state") != "open":
                continue
            banner = entry.get("banner")
            if not banner:
                continue
            line = _banner_line(int(entry.get("port") or 0), str(banner))
            if line:
                pseudo.append({"type": "PORT_SCAN", "url": subject, "evidence": line})

    return pseudo, subject


def _to_finding(item: dict, fallback_subject: str) -> Finding:
    subtype = str(item.get("subtype") or "CVE_LOOKUP")
    subject = str(item.get("url") or fallback_subject or "")
    rule_id = f"cve:{subtype}"
    return Finding(
        id=finding_id(rule_id, subject),
        rule_id=rule_id,
        title=str(item.get("title") or ""),
        severity=str(item.get("severity") or "INFO").upper(),
        confidence="high",
        subject=subject,
        message=str(item.get("description") or ""),
        why=str(item.get("evidence") or ""),
        fix=str(item.get("recommendation") or ""),
        verify="",
        tags=("exposure",),
    )


def lookup_from_observations(observations) -> list[Finding]:
    """ポート観測から CVE 候補の Finding を作る。失敗しても診断は止めない。"""
    pseudo, subject = _pseudo_findings(observations)
    if not pseudo:
        return []
    try:
        return [_to_finding(item, subject) for item in lookup_cve_candidates(pseudo)]
    except Exception:
        return []